﻿
using System;

namespace Chapter7 {
    public class Program{
        
        public static void Main() {
            for (long counter = 0; counter < 10; ++counter) {
                Console.WriteLine($"{counter}! = {Factorial(counter)}");
            }

            Console.WriteLine($"The sum of 2 + 3 is {Sum(2, 3)}\n\n");

            int x = 10;
            int z;


            Console.WriteLine($"x squared is {Square(x)}, the value of x is {x}");
            Console.WriteLine($"The value of x before pass by reference is {x}");
            SquareRef(ref x);
            Console.WriteLine($"The value of x after SquareRef is {x}");
            SquareOut(out z);
            Console.WriteLine($"The value of z after SquareOut is {z}");
        }

        //end main

        static double Maximum(double x, double y, double z)
        {
            double maximumValue = x;

            if (y > maximumValue)
            {
                maximumValue = y;
            }

            if (z > maximumValue)
            {
                maximumValue = z;
            }

            return maximumValue;

        }
        static int Power(int baseValue, int exponentValue = 2)
        {
            int result = 1;

            for (int i = 0; i < exponentValue; i++)
            {
                result *= baseValue;
            }

            return result;

        }

        static long Factorial(long number) {

            if (number <= 1)
            {
                return 1;
            }
            else {
                return number * Factorial(number - 1);
            }

        }

        static int Sum(int a, int b){

            return a + b;
        }

        static int Square(int x) {
            x = x * x;
            return x;
        }

        static void SquareRef(ref int x) {
            x = x * x;
        }

        static void SquareOut(out int x) {
            x = 6;

            x = x * x;
        }

    }
}
