﻿using System;

namespace Chapter11
{
    public class Program
    {
        public static void Main()
        {
            var employeeTest = new BasePlusCommissionEmployeeTest();
        }
    }
}
