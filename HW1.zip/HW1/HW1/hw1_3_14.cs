﻿namespace hw1 {

    public class hw_1_3_14
    {

        public static void Main(string[] args)
        {
            int a = 1;
            int b = 2;
            int c = 3;
            int d = 4;



            Console.WriteLine("1 2 3 4");

            Console.Write("1");
            Console.Write(" 2");
            Console.Write(" 3");
            Console.Write($" 4\n");


            Console.WriteLine($"{a} {b} {c} {d}");
        }
    }
}