﻿namespace GradeAggregator
{
    public class Program
    {
        public static void Main(string[] args)
        {

            int total = 0;
            int gradeCount = 0;
            int aCount = 0;
            int bCount = 0;
            int cCount = 0;
            int dCount = 0;
            int fCount = 0;



            Console.WriteLine("Enter the integer grades in the range 0-100");
            Console.WriteLine("Type <ctrl> z and press enter to terminate the program.");

            string input = Console.ReadLine();

            while (input != null) {

                int grade = int.Parse(input);
                total += grade;
                gradeCount++;

                switch (grade/10) {
                    case 9:
                    case 10:
                        ++aCount;
                        break;
                    case 8:
                        ++bCount;
                        break;
                    case 7:
                        ++cCount;
                        break;
                    case 6:
                        ++dCount;
                        break;
                    default:
                        ++fCount;
                        break;



                }

                input = Console.ReadLine();

            }




        }
    }
}

