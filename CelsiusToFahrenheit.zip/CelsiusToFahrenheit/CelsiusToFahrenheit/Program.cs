﻿using System;

public class Program
{
    public static void Main()
    {
        //prompt and read a double value from the user
        Console.Write("Enter a degree in Celsius: ");
        double celsius = double.Parse(Console.ReadLine());

        //convert the celsius value to fahrenheit
        double fahrenheit = ((9.0 / 5) * celsius) + 32;

        //output the result
        Console.WriteLine($"{celsius} Celsius is {fahrenheit} Fahrenheit");

        //hold the screen
        Console.ReadLine();
    }

}
