﻿// See https://aka.ms/new-console-template for more information
namespace GradeCounter {

    public class Program {

        public static void Main(string[] args) {
            /*
            int total = 0;
            int gradeCounter = 1;
            int average;

            while (gradeCounter <= 10) {
                Console.WriteLine($"Enter grade {gradeCounter}: ");
                total += int.Parse(Console.ReadLine());

                gradeCounter += 1;
            }
            average = total / 10;
            Console.WriteLine($"The average is {average}.");
            */

            //Sentinal controlled
            int total = 0;
            int gradeCounter = 0;
            int grade;
            double average;

            Console.WriteLine("Enter grade or -1 to quit: ");
            grade = int.Parse(Console.ReadLine());


            while (grade != -1)
            {
                total += grade;
                gradeCounter += 1;
                Console.WriteLine($"Enter grade or -1 to quit: ");
                grade = int.Parse(Console.ReadLine());


            }

            if (gradeCounter > 0)
            {
                average = (double)total / gradeCounter;
                Console.WriteLine($"The total of the {gradeCounter} grades entered is {total}.");
                Console.WriteLine($"The average is {average:F}.");
            }
            else {
                Console.WriteLine("No grade entered");
            }
        }
    }
}

