﻿using System;
namespace Account
{
    class  Account
    {
        private string name;

        public void setName(string accountName) {
            name = accountName;
        }

        public string getName() {
            return name;
        }
    }
}

