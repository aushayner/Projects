﻿using System;
namespace Account
{
    public class Account2
    {
        private string name;

        public string Name{ get; set;}

        private decimal balance;

        //Balance property
        public decimal Balance {
            get
            {
                return balance;
            }
            private set
            {
                //includes validation
                if (value > 0.0m) {
                    balance = value;
                }
            }
        }

        public Account2(string accountName, decimal initialBalance) {
            Name = accountName;
            Balance = initialBalance;

        }

        public void Deposit(decimal depositAmount) {
            if (depositAmount > 0.0m) {
                balance += depositAmount;
            }
        }

     }


}


