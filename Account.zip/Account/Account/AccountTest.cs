﻿using System;
namespace Account
{
    public class AccountTest
    {
        public static void Main() { 
            /*
            Account myAccount = new Account();

            Console.WriteLine($"Initial name is: {myAccount.getName()}");

            Console.Write("Enter the name: ");
            string theName = Console.ReadLine();
            myAccount.setName(theName);

            Console.WriteLine($"myAccount's name is: {myAccount.getName()}");
            */

            //Construct two objects of type account2
            Account2 account1 = new Account2("Jane Green", 50.00m);
            Account2 account2 = new Account2("John Blue", -7.53m);

            //Display the balance of both accounts
            Console.WriteLine($"{account1.Name}'s balance : {account1.Balance:C}");
            Console.WriteLine($"{account2.Name}'s balance : {account2.Balance:C}");

            //Prompt user for input for deposit ammount into account1
            Console.Write("\nEnter deposit amount for account1: ");
            decimal depositAmount = decimal.Parse(Console.ReadLine());
            Console.WriteLine($"adding {depositAmount:C} to account1 balance\n");
            //Use the Deposit property to add the deposit amount to the balance
            account1.Deposit(depositAmount);

            //Display current balances
            Console.WriteLine($"{account1.Name}'s balance: {account1.Balance:C}");
            Console.WriteLine($"{account2.Name}'s balance: {account2.Balance:C}");

            //Prompt user for deposit amount into account 2
            Console.Write("\nEnter deposit amount for account2: ");
            depositAmount = decimal.Parse(Console.ReadLine());
            Console.WriteLine($"adding {depositAmount:C} to account2 balance\n");
            //Use the Deposit property to add the deposit amount into account 2
            account2.Deposit(depositAmount);

            //Display current account balances
            Console.WriteLine($"{account1.Name}'s balance: {account1.Balance:C}");
            Console.WriteLine($"{account2.Name}'s balance: {account2.Balance:C}");


        }
    }
}
