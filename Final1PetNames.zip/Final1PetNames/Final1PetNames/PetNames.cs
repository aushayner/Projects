﻿using System;
namespace Final1PetNames
{
    public class PetNames
    {
        public static void Main()
        {
            
            List<string> names = new List<string>();

            string next = " ";

            while(next != "")
            {
                Console.Write("Enter next pet name or RETURN to exit: ");
                next = Console.ReadLine();

                if (next == "")
                {
                    break;
                }
                else
                {
                    names.Add(next);
                }
            }
           

            var namesAscending = from e in names
                         orderby e.Length ascending
                         select e;

            Console.WriteLine("List in ascending order by length of name: ");
            foreach(string element in namesAscending){
                Console.Write($"{element} ");
                
            }
            Console.WriteLine();


            var namesDescending = from e in names
                                 orderby e.Length descending
                                 select e;


            Console.WriteLine("List in descending order by length of name: ");
            foreach (string element in namesDescending)
            {
                Console.Write($"{element} ");

            }
            Console.WriteLine();

            var namesUnique = names.Distinct();

            int i = 0;
            foreach (string element in namesUnique)
            {
                i += 1;
            }

            Console.WriteLine($"List length with no duplicates: {i}");


            Console.ReadLine();

        }
    }
}

