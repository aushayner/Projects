﻿

public class Animal
{
    public virtual void animalSound()
    {
        Console.WriteLine("This is an animal sound");
    }
}

public class Dog : Animal
{
    public override void animalSound()
    {
        Console.WriteLine("Bork Bork");
    }
}

public class Cat : Animal
{
    public override void animalSound()
    {
        Console.WriteLine("Mew Mew");
    }
}

public class Duck : Animal
{
    public override void animalSound()
    {
        Console.WriteLine("Gua Gua");
    }
}

