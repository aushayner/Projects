﻿using System;
namespace Chapter9
{
    public class QueryLinq
    {
        public QueryLinq()
        {
            int[] array = new[] { 2, 9, 5, 0, 3, 7, 1, 4, 8, 5 };
            //display original values for array
            foreach (int element in array)
            {
                Console.WriteLine($"{element} ");
            }



            //Linq query that obtains values greater than or equal 4 from the array
            var filtered =
                from element in array //array is the data source we are querying on
                where element > 4
                select element;
            //Display the filtered result
            Console.WriteLine("\nArray values greater than 4: ");
            foreach (int element in filtered)
            {
                Console.Write($"{element} ");
            }
            Console.WriteLine();



            //use orderby clause to sort original values in ascending order
            var sorted =
                from element in array
                orderby element descending
                select element;
            //display sorted results
            Console.WriteLine("Original array, sorted: ");
            foreach (int element in sorted)
            {
                Console.Write($"{element} ");
            }
            Console.WriteLine();



            //sorted filtered results into descending order
            var sortFiltered =
                from element in filtered //data source is Linq query filtered
                orderby element descending
                select element;
            //display filtered sorted results
            Console.WriteLine("Filtered array, sorted: ");
            foreach (int element in sortFiltered)
            {
                Console.Write($"{element} ");
            }
            Console.WriteLine();



            //Alternative filter and sort in one query
            var filterAndSort =
                from element in array
                where element > 4
                orderby element descending
                select element;
            //display filtered sorted results
            Console.WriteLine("Filtered array, sorted(one query): ");
            foreach (int element in filterAndSort)
            {
                Console.Write($"{element} ");
            }
        }
    }
}

