﻿using System.Linq;
using System.Xml.Linq;

namespace Chapter9
{
    internal class Program
    {
        static void Main(string[] args) {
            var a = new EmployeeTest();
        }
    }
}

