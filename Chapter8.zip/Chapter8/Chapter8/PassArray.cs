﻿using System;
namespace Chapter8
{
    public class PassArray
    {
        public PassArray()
        {
            int[] array = { 1, 2, 3, 4, 5};

            Console.WriteLine("Effects of passing reference to entire array: ");
            Console.WriteLine("The values of the origional array are: ");

            // ouput the original array elements
            foreach (var value in array) {
                Console.Write($"    {value}");
            }

            Console.WriteLine("\n\nEffects of passing array element value:\n" +
                $"array[3] before ModifyElement{array[3]}");

            ModifyArray(array);

            Console.WriteLine("\n\nThe values of the modified array are: ");

            // ouput the original array elements
            foreach (var value in array)
            {
                Console.Write($"    {value}");
            }

        }

        static void ModifyArray(int[] array2)
        {
            for (var counter = 0; counter < array2.Length; ++counter) {
                array2[counter] *= 2;
            }

        }

        static void ModifyElement(int element)
        {
            element *= 2;
            Console.WriteLine($"Value of element in ModifyElement: {element}");
        }
    }
}

