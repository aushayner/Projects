﻿using System;

namespace Chapter8
{
    internal class Program
    {

        static void Main()
        {

            /* Function Calls */

            fun1();

            fun2();

            Grades();

            PassArray array = new PassArray();

            Console.WriteLine();

            MultidimensionalArrays c = new MultidimensionalArrays();


        } // end of Main

        /***********************************************************************/

        public static void fun1()
        {
            /* Array initialization and Array.Resize() method */

            int[] array = new int[5]; // elements are initialized to 0
            int[] initializedArray = { 32, 27, 64, 18, 95 };
            Array.Resize(ref initializedArray, 10); //new elements are initialized to 0
            Array.Resize(ref initializedArray, 3);


            Console.WriteLine($"{"Index"}{"Value",8}");
            for (int counter = 0; counter < array.Length; counter++)
            {
                Console.WriteLine($"{counter,5}{array[counter],8}");
            }

            Console.WriteLine($"{"Index"}{"Value for initialized array",30}");
            for (int counter = 0; counter < initializedArray.Length; counter++)
            {
                Console.WriteLine($"{counter,5}{initializedArray[counter],17}");
            }
        }

        /***********************************************************************/

        public static void fun2()
        {
            /* For each loop example */

            int[] array2 = { 87, 91, 43, 25, 19, 72, 34, 39, 1, 7, 54 };
            int total = 0;
            for (int i = 0; i < array2.Length; i++)
            {
                total += array2[i];
            }
            Console.WriteLine($"Total of array elements: {total}");
            int sum = 0;
            foreach (int num in array2)
            {
                sum += num;
            }
            Console.WriteLine($"Sum of array elements: {sum}");
        }

        /**********************************************************************/

        public static void Grades()
        {
            /* Bar chart */

            int[] grades = { 0, 0, 0, 0, 0, 0, 1, 2, 4, 2, 1 };
            Console.WriteLine("Grade Distribution:");
            for (var counter = 0; counter < grades.Length; ++counter)
            {
                if (counter == 10)
                {
                    Console.Write(" 100:   ");
                }
                else
                {
                    Console.Write($"{counter * 10: D2}-{counter * 10 + 9:D2}: ");
                }

                for (var stars = 0; stars < grades[counter]; ++stars)
                {
                    Console.Write("*");
                }

                Console.WriteLine();
            }

        }


    }
}
