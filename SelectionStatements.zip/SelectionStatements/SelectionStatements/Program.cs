﻿namespace SelectionStatements {

    public class Program {

        public static void Main(String[] args) {

            Console.Write("Student Grade: ");
            int grade = int.Parse(Console.ReadLine());
            String prefix = "Your grade is ";

            if (grade >= 90)
            {
                Console.WriteLine(prefix + "A");
            }
            else if (grade >= 80)
            {
                Console.WriteLine(prefix + "B");
            }
            else if (grade >= 70)
            {
                Console.WriteLine(prefix + "C");
            }
            else if (grade >= 60)
            {
                Console.WriteLine(prefix + "D");
            }
            else
            {
                Console.WriteLine(prefix + "F");

            }

            Console.WriteLine(grade >= 60 ? "Passed" : "Failed");
          


        }

    }

}



